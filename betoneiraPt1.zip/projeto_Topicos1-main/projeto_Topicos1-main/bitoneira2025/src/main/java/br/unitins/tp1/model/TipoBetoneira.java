package br.unitins.tp1.model;

public enum TipoBetoneira {
    HORIZONTAL,
    VERTICAL,
    EIXO_INCLINADO
}